import { SetupInstructions } from "@/setup-instructions"

export default function SetupPage() {
  return <SetupInstructions />
}
